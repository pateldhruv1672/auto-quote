import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';

dotenv.config({ path: '../.env' });

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// API Keys
const YUTORI_API_KEY = process.env.YUTORI_API_KEY;
const FREEPIK_API_KEY = process.env.FREEPIK_API_KEY;

// Helper: Poll for Freepik task completion
async function pollFreepikTask(taskId: string, maxAttempts = 30): Promise<string> {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    const response = await axios.get(
      `https://api.freepik.com/v1/ai/image-to-prompt/${taskId}`,
      {
        headers: {
          'x-freepik-api-key': FREEPIK_API_KEY,
        },
      }
    );

    const data = response.data.data;
    if (data.status === 'COMPLETED' && data.generated && data.generated.length > 0) {
      return data.generated[0];
    } else if (data.status === 'FAILED') {
      throw new Error('Image analysis failed');
    }
  }
  throw new Error('Timeout waiting for image analysis');
}

// Helper: Poll for Yutori research completion
async function pollYutoriResearch(taskId: string, maxAttempts = 60): Promise<any> {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise((resolve) => setTimeout(resolve, 5000));

    const response = await axios.get(
      `https://api.yutori.com/v1/research/tasks/${taskId}`,
      {
        headers: {
          'X-API-Key': YUTORI_API_KEY,
        },
      }
    );

    const data = response.data;
    if (data.status === 'succeeded') {
      return data;
    } else if (data.status === 'failed') {
      throw new Error('Research task failed');
    }
    
    console.log(`Research task ${taskId} status: ${data.status}`);
  }
  throw new Error('Timeout waiting for research');
}

// Endpoint: Analyze car damage image
app.post('/api/analyze-image', async (req: Request, res: Response) => {
  try {
    const { image } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image is required' });
    }

    if (!FREEPIK_API_KEY) {
      // Return mock description if no API key
      console.log('No FREEPIK_API_KEY, returning mock description');
      return res.json({
        description: 'Car with visible damage including dents, scratches, and potential body work needed. The damage appears to require professional auto body repair services.',
      });
    }

    // Call Freepik Image-to-Prompt API
    const response = await axios.post(
      'https://api.freepik.com/v1/ai/image-to-prompt',
      {
        image: `data:image/jpeg;base64,${image}`,
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'x-freepik-api-key': FREEPIK_API_KEY,
        },
      }
    );

    const taskId = response.data.data.task_id;
    console.log(`Freepik task created: ${taskId}`);

    // Poll for completion
    const description = await pollFreepikTask(taskId);

    // Enhance description for car damage context
    const enhancedDescription = `Car damage analysis: ${description}. This vehicle requires repair services for the visible damage.`;

    res.json({ description: enhancedDescription });
  } catch (error: any) {
    console.error('Image analysis error:', error.response?.data || error.message);
    res.status(500).json({
      error: 'Failed to analyze image',
      description: 'Car with visible damage requiring professional auto body repair.',
    });
  }
});

// Endpoint: Search for repair shops
app.post('/api/search-shops', async (req: Request, res: Response) => {
  try {
    const { location, latitude, longitude, damageDescription, radiusMiles = 5 } = req.body;

    if (!location) {
      return res.status(400).json({ error: 'Location is required' });
    }

    console.log(`Searching for repair shops near ${location}, damage: ${damageDescription}`);

    if (!YUTORI_API_KEY) {
      // Return mock data if no API key
      console.log('No YUTORI_API_KEY, returning mock data');
      return res.json({
        shops: generateMockShops(latitude, longitude),
        search_location: location,
        search_radius_miles: radiusMiles,
        total_found: 5,
        damage_description: damageDescription,
      });
    }

    // Build enhanced query based on damage description
    const query = `Find all vehicle repair shops, auto body shops, and car service centers within ${radiusMiles} miles of ${location}.
    
    The customer needs repairs for: ${damageDescription || 'general vehicle damage'}
    
    For each shop, provide:
    - Shop name
    - Full address (street, city, state, zip code)  
    - Phone number
    - Website (if available)
    - Rating and number of reviews
    - Sample customer reviews (2-3 reviews)
    - Services offered (especially those relevant to the damage described)
    - Hours of operation
    - Approximate latitude and longitude coordinates
    - Distance from ${location}
    
    Focus on highly-rated shops that specialize in the type of repair needed.`;

    // Create Yutori research task
    const createResponse = await axios.post(
      'https://api.yutori.com/v1/research/tasks',
      {
        query,
        user_location: location,
        user_timezone: 'America/Los_Angeles',
        task_spec: {
          output_schema: {
            type: 'json',
            json_schema: {
              type: 'object',
              properties: {
                shops: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      shop_name: { type: 'string' },
                      address: { type: 'string' },
                      city: { type: 'string' },
                      state: { type: 'string' },
                      zip_code: { type: 'string' },
                      phone_number: { type: 'string' },
                      website: { type: 'string' },
                      rating: { type: 'number' },
                      review_count: { type: 'number' },
                      reviews: { type: 'array', items: { type: 'string' } },
                      services: { type: 'array', items: { type: 'string' } },
                      hours_of_operation: { type: 'string' },
                      latitude: { type: 'number' },
                      longitude: { type: 'number' },
                      distance_miles: { type: 'number' },
                    },
                    required: ['shop_name', 'address', 'city', 'state', 'phone_number'],
                  },
                },
              },
              required: ['shops'],
            },
          },
        },
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': YUTORI_API_KEY,
        },
      }
    );

    const taskId = createResponse.data.task_id;
    console.log(`Yutori research task created: ${taskId}`);
    console.log(`View at: ${createResponse.data.view_url}`);

    // Poll for completion
    const result = await pollYutoriResearch(taskId);

    // Parse results
    let shops = [];
    if (result.structured_result?.shops) {
      shops = result.structured_result.shops;
    }

    // Add coordinates if missing (geocode addresses)
    for (const shop of shops) {
      if (!shop.latitude || !shop.longitude) {
        try {
          const geoResponse = await axios.get(
            `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(
              `${shop.address}, ${shop.city}, ${shop.state}`
            )}&format=json&limit=1`
          );
          if (geoResponse.data.length > 0) {
            shop.latitude = parseFloat(geoResponse.data[0].lat);
            shop.longitude = parseFloat(geoResponse.data[0].lon);
          }
        } catch (geoError) {
          console.error('Geocoding error:', geoError);
        }
      }
    }

    res.json({
      shops,
      search_location: location,
      search_radius_miles: radiusMiles,
      total_found: shops.length,
      damage_description: damageDescription,
    });
  } catch (error: any) {
    console.error('Search error:', error.response?.data || error.message);
    
    // Return mock data on error
    res.json({
      shops: generateMockShops(req.body.latitude, req.body.longitude),
      search_location: req.body.location,
      search_radius_miles: req.body.radiusMiles || 5,
      total_found: 5,
      damage_description: req.body.damageDescription,
      error: 'Using mock data due to API error',
    });
  }
});

// Generate mock shops for testing
function generateMockShops(centerLat: number, centerLon: number) {
  const shops = [
    {
      shop_name: 'Elite Auto Body & Repair',
      address: '1234 Main Street',
      city: 'San Jose',
      state: 'CA',
      zip_code: '95112',
      phone_number: '(408) 555-1234',
      website: 'https://eliteautobody.com',
      rating: 4.8,
      review_count: 256,
      reviews: ['Excellent service!', 'Fixed my car perfectly.'],
      services: ['Collision Repair', 'Dent Removal', 'Paint Work', 'Frame Straightening'],
      hours_of_operation: 'Mon-Fri 8am-6pm, Sat 9am-4pm',
      latitude: centerLat + 0.01,
      longitude: centerLon + 0.01,
      distance_miles: 0.8,
    },
    {
      shop_name: 'Pacific Coast Auto Care',
      address: '567 Oak Avenue',
      city: 'San Jose',
      state: 'CA',
      zip_code: '95113',
      phone_number: '(408) 555-5678',
      website: 'https://pacificcoastauto.com',
      rating: 4.6,
      review_count: 189,
      reviews: ['Great prices and quick turnaround.', 'Very professional team.'],
      services: ['Body Repair', 'Bumper Repair', 'Scratch Removal', 'Insurance Claims'],
      hours_of_operation: 'Mon-Fri 7:30am-5:30pm',
      latitude: centerLat - 0.015,
      longitude: centerLon + 0.02,
      distance_miles: 1.2,
    },
    {
      shop_name: 'Bay Area Collision Center',
      address: '890 Tech Drive',
      city: 'San Jose',
      state: 'CA',
      zip_code: '95110',
      phone_number: '(408) 555-8901',
      website: 'https://bayareacollision.com',
      rating: 4.9,
      review_count: 412,
      reviews: ['Best collision repair in the area!', 'They made my car look brand new.'],
      services: ['Complete Collision Repair', 'Paintless Dent Repair', 'Auto Glass', 'Detailing'],
      hours_of_operation: 'Mon-Sat 8am-6pm',
      latitude: centerLat + 0.02,
      longitude: centerLon - 0.015,
      distance_miles: 1.8,
    },
    {
      shop_name: 'QuickFix Auto Body',
      address: '321 Industrial Blvd',
      city: 'San Jose',
      state: 'CA',
      zip_code: '95111',
      phone_number: '(408) 555-3210',
      rating: 4.4,
      review_count: 98,
      reviews: ['Fast and affordable!', 'Good quality work.'],
      services: ['Minor Repairs', 'Dent Removal', 'Touch-up Paint', 'Bumper Replacement'],
      hours_of_operation: 'Mon-Fri 9am-5pm',
      latitude: centerLat - 0.008,
      longitude: centerLon - 0.025,
      distance_miles: 2.1,
    },
    {
      shop_name: 'Premium Auto Restoration',
      address: '456 Luxury Lane',
      city: 'San Jose',
      state: 'CA',
      zip_code: '95125',
      phone_number: '(408) 555-4567',
      website: 'https://premiumautorestore.com',
      rating: 4.7,
      review_count: 167,
      reviews: ['Premium quality service.', 'Expensive but worth it.'],
      services: ['Full Restoration', 'Custom Paint', 'Classic Car Repair', 'Luxury Vehicle Specialist'],
      hours_of_operation: 'Mon-Fri 8am-5pm',
      latitude: centerLat + 0.025,
      longitude: centerLon + 0.018,
      distance_miles: 2.5,
    },
  ];

  return shops;
}

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Backend server running on http://localhost:${PORT}`);
  console.log(`   YUTORI_API_KEY: ${YUTORI_API_KEY ? '✓ Set' : '✗ Not set (using mock data)'}`);
  console.log(`   FREEPIK_API_KEY: ${FREEPIK_API_KEY ? '✓ Set' : '✗ Not set (using mock data)'}`);
});
